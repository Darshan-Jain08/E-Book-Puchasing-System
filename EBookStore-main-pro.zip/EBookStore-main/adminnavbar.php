<nav style="font-family: 'Segoe UI';">
    <div class="nav-menu">
        <label class="Logo">E-Book Store</label>
        <a class="nav-menu-btn" href="AdminHome.php">Dashboard</a>
        <a class="nav-menu-btn" href="bookslist.php">E-Books</a>
        <a class="nav-menu-btn" href="BookCategoryList.php">Category</a>
        <a class="nav-menu-btn" href="Userlist.php">Users</a>
        <a class="nav-menu-btn" href="BookPurchaseReport.php">Book Purchase report</a>
    </div>
    
    <a class="primarybtn" href="logout.php?id=2">LOG OUT</a>
</nav>