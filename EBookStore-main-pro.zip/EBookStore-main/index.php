<!DOCTYPE html>
<html>
<head>
    <title>E-Book</title> 
    <link rel="stylesheet" href="CSS/comman.css">
    <link rel="stylesheet" href="CSS/index.css">
</head>
<body>
    <nav>
        <label class="Logo">E-Book Store</label>
        <a class="primarybtn" href="AdminLogin.php">ADMIN</a>
    </nav>
    <hr>
    <div class="mainbody">
        <h1 class="heading1">E-Books</h1>
        <div class="btnsec">
            <a class="btn login" href="UserLogin.php">Login</a>
            <a class="btn signin" href="UserSignin.php">SignUp</a>
        </div>
    </div>
    </div>
</body>
</html>